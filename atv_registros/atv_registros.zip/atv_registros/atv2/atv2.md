Uma pré escola tem 5 alunos, crie uma estrutura
que armazene nome, telefone de emergencia, idade,
contato de emergencia;

Crie um vetor com 5 dessas estruturas

Crie uma função para ler as informações de UM
aluno; chame a função 5 vezes.

Crie uma função que recebe como parâmetro o
índice do aluno e escreva todos os dados na tela de
maneira organizada.

As funções acima recebem o índice do aluno como
parâmetro e alteram o array global que contém os
alunos.
