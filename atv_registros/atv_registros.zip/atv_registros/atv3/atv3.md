Crie uma estrutura que armazene o nome de um
aluno, numero de matricula, 4 notas e faltas.

Crie um vetor para armazenar 5 alunos.

Crie uma função para ler os dados de um aluno.

Crie uma função para escrever na tela os dados de
um aluno

Crie uma função que retorne a média do aluno

Crie uma função que escreva a situação do aluno

As funções acima recebem o índice do aluno como
parâmetro e alteram o array global que contém os
alunos.
