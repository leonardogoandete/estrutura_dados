Exercicio 1

Sua empresa o contratou para desenvolver uma agenda
para uma pessoa solitária que tem apenas o telefone da
mãe e um amigo.

Esta agenda deve ter capacidade para armazenar o
nome, telefone, celular, endereço e aniversário.

A agenda deve ser capaz de inserir os dados de todos os
contatos (máx 3: A mãe, o amigo e ele mesmo)

Após a inserção de todos os contatos deve perguntar ao
usuário o número do contato que ele quer visualizar,
caso o número esteja fora do intervalo (1 a 3), o
programa termina, caso contrário o programa escreve
na tela os dados e pergunta novamente.

Este programa nao precisa ter funções além da principal
